import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: {
      main: "#0097b2",
    },
    secondary: {
      main: "#fabc00",
    },
  },
  typography: {
    fontFamily: "Open Sans, sans-serif",
    fontSize: 16,
    // fontWeightRegular: 300,
    color: "GrayText",
  },
});

export default theme;
