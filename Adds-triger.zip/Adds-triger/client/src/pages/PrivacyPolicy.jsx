import { Box, Typography } from "@mui/material";
import React from "react";
import Navbar from "../components/Navbar/Navbar";
import Footer from "../components/Footer/Footer";

const PrivacyPolicy = () => {
  return (
    <>
      <Navbar />
      <Box width={"85%"} marginX={"auto"}>
        <p style={{ fontWeight: 600, fontSize: "25px", margin: "10px 0" }}>
          Privacy Policies
        </p>
        <p style={{ margin: "10px 0" }}>Your privacy is very important to us</p>
        <ol style={{ padding: "0 40px" }}>
          <div className="container">
            <li className="bold">introduction</li>
            <p>
              Saleway GmbH, a company registered in Switzerland (registration
              number: CH-036.4.066.369-4) operates https://www.adtriggers.net
              (hereinafter referred to as "Service" ). Our Privacy Policy
              governs your visit to https://www.adtriggers.net and explains how
              we collect, secure and disclose information resulting from your
              use of our service. We use your data to provide and improve the
              service. By using the service, you consent to the collection and
              use of information in accordance with this policy.
            </p>
          </div>
          <div className="container">
            <li className="bold">Definations</li>
            <p className="container">
              <b>SERVICE</b> means the website operated by us
              (https://www.adtriggers.net)
            </p>
            <p className="container">
              <b>PERSONAL DATA</b> is data about a living individual that has
              been determined from such data (or from this and other information
              either in our possession or likely to be in our possession ). will
              come into possession) can be identified.
            </p>
            <p className="container">
              <b>USAGE DATA</b> means data that is collected automatically,
              either through the use of the Service or through the Service
              infrastructure itself (e.g. the duration of a page visit).
            </p>
            <p className="container">
              <b>COOKIES</b> are small files that are stored on your device
              (computer or mobile device).
            </p>
            <p className="container">
              <b>DATA CONTROLLER</b> means a natural or legal person who (either
              alone or jointly with other persons) determines the purposes for
              which and how personal data are or are to be processed. For the
              purposes of this Privacy Policy, we are a data controller of your
              data.
            </p>
            <p className="container">
              <b>DATA PROCESSOR (OR SERVICE PROVIDER)</b> means any natural or
              legal person who processes the data on behalf of the data
              controller. We may use the services of various service providers
              to process your data more effectively.
            </p>
            <p className="container">
              <b>DATA SUBJECT</b> is any living individual who is the subject of
              Personal Data.
            </p>
            <p className="container">
              <b>THE USERS</b> Person using our Service. The user corresponds to
              the data subject who is the subject of personal data.
            </p>
          </div>
          <div className="container">
            <li className="bold">Collection and use of information</li>
            <p>
              We collect different types of information for different purposes
              to provide and improve our service to you.
            </p>
          </div>
          <div className="container">
            <li className="bold">Types of Data Collected</li>
            <ol style={{ padding: "0 40px" }}>
              <div className="container">
                <li>
                  <b>Personal Information</b>
                </li>
                <p>
                  While using our Service, we may ask you to provide us with
                  certain personally identifiable information that can be used
                  to contact or identify you (“Personal Information”).
                  Personally identifiable information may include, but is not
                  limited to:
                  <ol style={{ padding: "0 40px" }}>
                    <li>Email-address</li>
                    <li>username</li>
                    <li>Cookies and Usage Data</li>
                  </ol>
                </p>
              </div>
              <div className="container">
                <li>
                  We may use your personal information to contact you with
                  newsletters, marketing or promotional materials and other
                  information that may be of interest to you. You may opt out of
                  receiving some or all of these communications from us by
                  following the unsubscribe link or by emailing
                  info@salesangels.org .
                </li>
              </div>
              <div className="container">
                <li>
                  <b>Usage Data</b>
                </li>
                <p>
                  We may also collect information that your browser sends when
                  you visit our Service or when you access the Service with or
                  through a mobile device (" Usage Data "). This Usage Data may
                  include information such as your computer's Internet Protocol
                  address (e.g. IP address), browser type, browser version,
                  which pages of our Service you visit, the time and date of
                  your visit, the time spent on those pages Device identifiers
                  and other diagnostic data. If you access the Service using a
                  mobile device, this Usage Data may include information such as
                  the type of mobile device you are using, your mobile device's
                  unique ID, your mobile device's IP address, your mobile
                  operating system and the type of mobile internet browser you
                  are using, unique Device identifiers and other diagnostic
                  data.
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Tracking Cookies</b>
                </li>
                <p>
                  Information We use cookies and similar tracking technologies
                  to track activity on our Service, and we store certain
                  information.
                  <br />
                  <br />
                  Cookies are files with a small amount of data that may contain
                  an anonymous unique identifier. Cookies are sent to your
                  browser from a website and stored on your device. Other
                  tracking technologies such as beacons, tags and scripts are
                  also used to collect and track information and to improve and
                  analyze our Service.
                  <br /> <br />
                  You can instruct your browser to refuse all cookies or to
                  indicate when a cookie is being sent. However, if you do not
                  accept cookies, you may not be able to use some parts of our
                  service. <br />
                  <br /> Examples of cookies we use:
                  <br />
                  <br />
                  <ol style={{ padding: "0 40px" }}>
                    <li>
                      <b>Session Cookies:</b> We use session cookies to operate
                      our Service.
                    </li>
                    <li>
                      <b>Preference Cookies:</b> We use Preference Cookies to
                      remember your preferences and various settings.
                    </li>
                    <li>
                      <b>Security Cookies:</b> We use security cookies for
                      security purposes.
                    </li>
                    <li>
                      <b>Advertising cookies:</b>Advertising cookies are used to
                      show you advertisements that may be relevant to you and
                      your interests.
                    </li>
                  </ol>
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Use of Data</b>
                </li>
                The tool uses the collected data for various purposes:
                <ol style={{ padding: "0 40px" }}>
                  <li>To provide and maintain our service</li>
                  <li>To notify you of changes to our service</li>
                  <li>
                    to enable you to participate in interactive features of our
                    Service when you choose to do so;
                  </li>
                  <li>to provide customer support;</li>
                  <li>
                    to collect analytics or valuable information so that we can
                    improve our service;
                  </li>
                  <li>to monitor the use of our service;</li>
                  <li>to detect, prevent and fix technical problems;</li>
                  <li>
                    to fulfill any other purpose for which you provide it;
                  </li>
                  <li>
                    to perform our obligations and enforce our rights arising
                    under any contract between you and us, including billing and
                    collection;
                  </li>
                  <li>
                    to send you notifications about your account and/or
                    subscription, including expiration and renewal
                    notifications, email instructions, etc.
                  </li>
                  <li>for other purposes with your consent.</li>
                </ol>
              </div>
              <div className="container">
                <li>
                  <b>Retention of Data</b>
                </li>
                <p>
                  We only store your personal data for as long as is necessary
                  for the purposes set out in this privacy policy. We retain and
                  use your personal information to the extent necessary to
                  comply with our legal obligations (for example, where we are
                  required to retain your information to comply with applicable
                  laws), resolve disputes, and enforce our legal agreements and
                  policies. We also store usage data for internal analysis
                  purposes. Usage Data is generally retained for a shorter
                  period of time, except when this data is used to enhance
                  security or to improve the functionality of our Service, or we
                  are required by law to retain this data for longer periods.
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Transfer of Data</b>
                </li>
                <p>
                  Your information, including Personal Data, may be transferred
                  to and stored on computers located outside of your state,
                  province, country or other governmental jurisdiction where the
                  data protection laws may differ from those of your
                  jurisdiction. Please note that we transfer and process the
                  data, including personal data, to the United States. Your
                  consent to this Privacy Policy, followed by your submission of
                  this information, constitutes your consent to that transfer.
                  The tool (website application) will take all steps reasonably
                  necessary to ensure that your information is treated securely
                  and in accordance with this Privacy Policy , and no transfer
                  of your personal data will take place to any organization or
                  country unless there are adequate controls in place, including
                  the security of your data and other personal information.
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Disclosure of information</b>
                </li>
                <ol style={{ padding: "0 40px" }}>
                  <div className="container">
                    <li>
                      <b>Disclosure of Law enforcement</b>
                    </li>
                    <p>
                      We may disclose Personal Information that we collect or
                      that you provide:
                    </p>
                  </div>
                  <div className="container">
                    <li>
                      <b>Business Transaction</b>
                    </li>
                    <p>
                      If we are involved in a merger, acquisition, or sale of
                      assets, your personal information may be transferred.
                    </p>
                  </div>
                  <li>
                    <b>other cases. We may also disclose your information:</b>
                  </li>
                  <p>
                    to contractors, service providers and other third parties we
                    use to support our business;
                  </p>
                </ol>
              </div>
              <div className="container">
                <li>
                  <b>Security of Information</b>
                </li>
                <p>
                  The security of your information is important to us, but
                  remember that no method of transmission over the Internet, or
                  method of electronic storage is 100% secure. While we strive
                  to use commercially acceptable means of protecting your
                  Personal Information, we cannot guarantee its absolute
                  security.
                </p>
              </div>
              <div>
                <li>
                  <b>
                    Your data protection rights under the General Data
                    Protection Regulation (GDPR)
                  </b>
                </li>
                <p>
                  If you are a resident of the European Union (EU) and the
                  European Economic Area (EEA), you have certain data protection
                  rights that are covered by the GDPR. – More information at
                  https://eur-lex.europa.eu/eli/reg/2016/679/oj We aim to take
                  reasonable steps to enable you to correct, amend, delete or
                  limit the use of your personal information. If you would like
                  to be informed about what personal information we hold about
                  you and to have it removed from our systems, please email us
                  at info@salesangels.org . <br /> You may have the following
                  data protection rights:
                  <div className="container">
                    <ol style={{ padding: "0 40px" }}>
                      <li>
                        the right to access, update or delete the information we
                        hold about you;
                      </li>
                      <li>
                        the right to rectification. You have the right to have
                        your information corrected if that information is
                        inaccurate or incomplete;
                      </li>
                      <li>
                        the right to object. You have the right to object to our
                        processing of your personal data;
                      </li>
                      <li>
                        the right of restriction. You have the right to request
                        that we restrict the processing of your personal data;
                      </li>
                      <li>
                        the right to data portability. You have the right to
                        receive a copy of your personal data in a structured,
                        machine-readable and commonly used format;
                      </li>
                      <li>
                        the right to withdraw consent. You also have the right
                        to withdraw your consent at any time where we are
                        relying on your consent to process your personal data;
                      </li>
                    </ol>
                  </div>
                </p>
              </div>
              <div className="container">
                <li>
                  Please note that we may ask you to verify your identity before
                  responding to such requests. Please note that we may not be
                  able to offer the service without some necessary data. You
                  have the right to complain to a data protection authority
                  about our collection and use of your personal information. For
                  more information, please contact your local data protection
                  authority in the European Economic Area (EEA).
                </li>
              </div>
              <div className="container">
                <li>
                  Our Do Not Track Signals Policy: We respect do-not-track
                  signals and do not track, set cookies, or use advertising
                  where a do-not-track browser mechanism is in place. Do Not
                  Track is a preference you can set in your web browser to
                  inform websites that you do not wish to be tracked. You can
                  enable or disable Do Not Track by visiting your web browser's
                  "Settings" or "Preferences" page.
                </li>
              </div>
              <div className="container">
                <li>
                  <b>Service Providers</b>
                </li>
                <p>
                  We may engage third-party companies and individuals to
                  facilitate our Service (" Service Providers "), to provide
                  Services on our behalf, to perform Service-related services,
                  or to help us analyze how our Service is used. These third
                  parties have access to your personal information only to
                  perform those tasks on our behalf and are obligated not to
                  disclose it or use it for any other purpose.
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Analytics</b>
                </li>
                <p>
                  We may use third party service providers to monitor and
                  analyze usage of our Service, which may include, but is not
                  limited to:
                  <ol style={{ padding: "0 40px" }}>
                    <li>
                      <b>Google Analytics</b>
                    </li>
                    <p>
                      Google Analytics is a web analytics service provided by
                      Google that tracks and reports website traffic. Google
                      uses the data collected to track and monitor the use of
                      our service. This data is shared with other Google
                      services. Google may use the data it collects to
                      contextualize and personalize the ads of its own
                      advertising network. <br />
                      For more information about Google's privacy practices,
                      please visit the Google Privacy Policy webpage:
                      https://policies.google.com/privacy We also encourage you
                      to read Google's privacy policy: https://support
                      .google.com/analytics/answer/6004245 .
                    </p>
                  </ol>
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Behavioral Remarketing</b>
                </li>
                <p>
                  Our site uses remarketing services to advertise to you on
                  third party websites after you have visited our Service. We
                  and our third parties use cookies to inform, optimize and
                  serve ads based on your previous visits to our service.
                  <ol style={{ padding: "0 40px" }}>
                    <li>
                      <b>Google Ads (Adwords)</b>
                    </li>
                    <p>
                      The Google Ads (AdWords) remarketing service is provided
                      by Google Inc. You can opt out of Google Analytics for
                      display advertising and customize the Google Display
                      Network ads by visiting the Google Ads Settings page:
                      https://www.google.com/settings/ads Google also recommends
                      that the browser Install the Google Analytics opt-out
                      add-on – https://tools.google.com/dlpage/gaoptout – for
                      your web browser. The Google Analytics opt-out browser
                      add-on offers visitors the opportunity to prevent their
                      data from being collected and used by Google Analytics.
                      For more information about Google's privacy practices,
                      visit the Google Privacy Policy webpage:
                      https://policies.google.com/privacy
                    </p>
                  </ol>
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Payments</b>
                </li>
                <p>
                  We may offer paid products and/or services within the Service.
                  In this case, we use third-party payment processing services
                  (e.g. payment processors). We will not store or collect your
                  payment card details. This information is shared directly with
                  our third-party payment processors, whose use of your personal
                  information is governed by their privacy policy. These payment
                  processors adhere to the standards set by PCI-DSS, which is
                  administered by the PCI Security Standards Council, a
                  collaborative effort by brands like Visa, Mastercard, American
                  Express, and Discover. PCI-DSS requirements help ensure the
                  secure handling of payment information. The payment processors
                  we work with are:
                  <ol style={{ padding: "0 40px" }}>
                    <li>
                      <b>Stripe:</b>
                    </li>
                    <p>
                      Their privacy policy can be viewed at:
                      https://stripe.com/us/privacy
                    </p>
                  </ol>
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Links to Other Websites</b>
                </li>
                <p>
                  Our Service may contain links to other websites that are not
                  operated by us. If you click on a third party link, you will
                  be directed to that third party's website. We strongly
                  encourage you to read the privacy policy of every website you
                  visit. We have no control over, and are not responsible for,
                  the content, privacy policies, or practices of any third-party
                  websites or services.
                </p>
              </div>
              <div className="container">
                <li>
                  <b>
                    API interfaces and third-party providers to carry out the
                    target group analysis and service .
                  </b>
                </li>
                <p>
                  We rely on various interfaces so that we can evaluate and
                  analyze the corresponding inquiries that you enter via the
                  search field on our website. We currently use the following
                  API interfaces: Custom Search API YouTube Data API v3 In order
                  to use it, we must comply with certain guidelines and terms of
                  use . Therefore, the number of analyzes is always limited and
                  we pay attention to misuse or unnecessary resource
                  utilization. By using our service, you agree to the terms of
                  use: https://www.youtube.com/static?template=terms . In
                  addition, any use of our service that is not performed
                  manually by a human (bots or similar) is prohibited. If you
                  are identified by violating the Terms of Service, Privacy
                  Policy or Policies, you will be liable for the damage.
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Children's Privacy</b>
                </li>
                <p>
                  Our Service is not directed to persons under the age of 18 (“
                  Children ”). We do not knowingly collect personally
                  identifiable information from anyone under the age of 18. If
                  you are a parent or legal guardian and you are aware that your
                  child has provided us with personal information, please
                  contact us. If we become aware that we have collected personal
                  information from children without verification of parental
                  consent, we will take steps to remove that information from
                  our servers.
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Changes to this Privacy Policy</b>
                </li>
                <p>
                  We may update our Privacy Policy from time to time. We will
                  notify you of any changes by posting the new privacy policy on
                  this page. We will notify you by email and/or a prominent
                  notice on our Service prior to the change becoming effective
                  and update the “Effective Date” at the top of this Privacy
                  Policy. It is recommended that you periodically review this
                  Privacy Policy for changes. Changes to this Privacy Policy are
                  effective when posted on this page.
                </p>
              </div>
              <div className="container">
                <li>
                  <b>Contact Us</b>
                </li>
                <p>
                  If you have any questions about this Privacy Policy, please
                  contact us at: info@salesangels.org
                </p>
              </div>
            </ol>
          </div>
        </ol>
      </Box>
      <Footer />
    </>
  );
};

export default PrivacyPolicy;
