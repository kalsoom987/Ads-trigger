import React from "react";
import { Typography, Box } from "@mui/material";
import Navbar from "../components/Navbar/Navbar";
import Nav from "../components/results/Nav";

const CookiePolicy = () => {
  return (
    <>
      <Navbar />
      <Box padding={2}>
        <Typography fontSize={30}>We are not using any Cookie</Typography>
      </Box>
    </>
  );
};

export default CookiePolicy;
