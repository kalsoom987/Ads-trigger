import React, { useRef, useState } from "react";
import Navbar from "../components/Navbar/Navbar";
import Footer from "../components/Footer/Footer";
import styles from "./Home.module.css";
import "react-responsive-carousel/lib/styles/carousel.min.css";
// import HeroSection from "../components/heroSection/HeroSection";
import HeroSection from "../components/heroSection/HeroSection";
import TextSection from "../components/textSection/TextSection";
import CardsDetail from "../components/cardsDetail/CardsDetail";
import Pricing from "../components/Pricing/Pricing";
import Results from "../components/results/Results";
import ColoredSection from "../components/ColoredSection/ColoredSection";

const Home = () => {
  // const resultRef = useRef();

  return (
    <>
      <Navbar />
      <HeroSection />
      <Results />
      <ColoredSection />
      <TextSection />
      <CardsDetail />
      <Pricing />
      <Footer />
    </>
  );
};

export default Home;
