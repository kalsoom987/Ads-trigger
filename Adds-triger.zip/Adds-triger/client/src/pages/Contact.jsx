import React, { useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import Footer from "../components/Footer/Footer";
import { Typography, Box, TextField, Button } from "@mui/material";
import LocationOnOutlinedIcon from "@mui/icons-material/LocationOnOutlined";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import PhoneOutlinedIcon from "@mui/icons-material/PhoneOutlined";

const Contact = () => {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://www.cognitoforms.com/f/iframe.js";
    script.async = true;
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <>
      <Navbar />
      <Box
        my={5}
        width={"90%"}
        mx={"auto"}
        backgroundColor={"white"}
        padding={3}
        borderRadius={5}
      >
        <Box
          display={{ xs: "block", md: "flex" }}
          justifyContent={"space-between"}
        >
          <Box flex={0.4}>
            <Typography variant="h4" color={"primary"} my={2}>
              Contact Us
            </Typography>
            <Typography my={2} fontSize={16}>
              Feel free to send us a message. We are currently in the Beta
              version, so it may take up to 48 hours for you to receive
              feedback.
            </Typography>
            <IconBox Icon={EmailOutlinedIcon} text={"pascal@saleway.ch"} />
            <IconBox Icon={PhoneOutlinedIcon} text={"1234567890"} />
            <IconBox
              Icon={LocationOnOutlinedIcon}
              text={`Pascal Schildknecht
              Saleway GmbH
              Schulhausgässli 4
              3098 Köniz
              Bern, Switzerland`}
            />
          </Box>
          {/* Contact us form */}
          {/* <Box flex={0.5}>
            <Typography variant="h4" color={"primary"} my={2}>
              Get in Touch
            </Typography>
            <Box display={"flex"} my={2}>
              <TextField label="First Name" fullWidth sx={{ mr: 1 }} />
              <TextField label="Last Name" fullWidth />
            </Box>
            <TextField label="Email" fullWidth sx={{ my: 1 }} />
            <TextField
              label="Message"
              multiline
              rows={3}
              fullWidth
              sx={{ my: 1 }}
            />
            <Button variant="contained">Submit</Button>
          </Box> */}
          <Box flex={0.5}>
            <Typography variant="h4" color={"primary"} my={2}>
              Get in Touch
            </Typography>
            <iframe
              src="https://www.cognitoforms.com/f/__Abyd03d0aIWQBphTDF7A/128"
              // style="border:0;width:100%;"
              style={{ width: "100%", border: 0 }}
              height="629"
            ></iframe>
          </Box>
        </Box>
      </Box>
      <Footer />
    </>
  );
};

export default Contact;

const IconBox = ({ Icon, text }) => {
  return (
    <Box display={"flex"} alignItems={"center"} my={2}>
      <Box>
        <Box
          backgroundColor={"#4f74a8"}
          height={40}
          width={40}
          borderRadius={50}
          display={"flex"}
          justifyContent={"center"}
          alignItems={"center"}
          color={"white"}
          mr={2}
        >
          <Icon />
        </Box>
      </Box>
      <Typography>{text}</Typography>
    </Box>
  );
};
