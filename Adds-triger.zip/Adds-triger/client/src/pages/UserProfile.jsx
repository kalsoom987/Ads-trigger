import React from "react";
import { Box, Typography, Button } from "@mui/material";

import { useUserStore } from "../store/user";
import { colors } from "../assets/colors";

import { auth } from "../firebaseConfig";
import { signOut } from "firebase/auth";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

import Navbar from "../components/Navbar/Navbar";

const UserProfile = () => {
  const user = useUserStore((state) => state.user);
  const setUser = useUserStore((state) => state.setUser);

  const navigate = useNavigate();

  // Function to logout user
  const logout = () => {
    console.log("logout");
    signOut(auth)
      .then(() => {
        navigate("/");
        setUser(null);
        toast.success("Logout Success");
        console.log("logout success");
        localStorage.removeItem("token");
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <Navbar />
      <Box display={"flex"} justifyContent={"center"} paddingX={3} mt={15}>
        <Box
          maxWidth={500}
          backgroundColor={"white"}
          className="shadow"
          borderRadius={3}
          padding={5}
        >
          <h1 color={colors.primary}>My Profile</h1>
          <Typography color={"primary"} fontWeight={"bold"} my={2}>
            Username:{" "}
            <span style={{ color: colors.primary, fontWeight: "normal" }}>
              {user?.displayName}
            </span>
          </Typography>

          <Typography color={"primary"} fontWeight={"bold"} my={2}>
            Email:{" "}
            <span style={{ color: colors.primary, fontWeight: "normal" }}>
              {user?.email}
            </span>
          </Typography>
          <Typography
            color={"primary"}
            fontWeight={"bold"}
            my={2}
            textTransform={"capitalize"}
          >
            Membership:{" "}
            <span style={{ color: colors.primary, fontWeight: "normal" }}>
              {user?.membership}
            </span>
          </Typography>
          <Typography
            color={"primary"}
            fontWeight={"bold"}
            my={2}
            textTransform={"capitalize"}
          >
            Remaining Search:{" "}
            <span style={{ color: colors.primary, fontWeight: "normal" }}>
              {user?.membership === "unlimited"
                ? "Unlimited"
                : (user?.membership === "free"
                    ? 3
                    : user?.membership === "daily"
                    ? 10
                    : user?.membership === "monthly"
                    ? 40
                    : user?.membership === "yearly"
                    ? 365
                    : 3) - user?.searchCount}
            </span>
          </Typography>
          <Button
            onClick={logout}
            variant="contained"
            //   color="secondary"
            size="small"
          >
            Logout
          </Button>
        </Box>
      </Box>
    </>
  );
};

export default UserProfile;
