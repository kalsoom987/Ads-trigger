import React, { useState } from "react";
import { Box, Button, TextField, Typography } from "@mui/material";
import envelope from "../assets/envelope.png";
import { toast } from "react-toastify";
import { auth } from "../firebaseConfig";
import { sendPasswordResetEmail } from "firebase/auth";
import { Link } from "react-router-dom";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  // Forgot password function using firebase
  const forgotPassword = () => {
    if (!email) {
      toast.error("Please Enter Email");
      return;
    }
    setLoading(true);
    sendPasswordResetEmail(auth, email)
      .then(() => {
        toast.success("Password Reset Email Sent");
        setLoading(false);
        setEmail("");
      })
      .catch((error) => {
        setLoading(false);
        console.log(error, "forgot passwrod");
      });
  };
  return (
    <Box maxWidth={400} mx={"auto"} marginTop={2} padding={2}>
      <Box
        display={"flex"}
        flexDirection={"column"}
        alignItems={"center"}
        width={"100%"}
      >
        <img src={envelope} width={200} />
        {/* <Box mb={2}> */}
        <TextField
          label="Email"
          value={email}
          name="email"
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          sx={{ marginBottom: 3 }}
        />
        {/* </Box> */}
        <Button variant="contained" onClick={forgotPassword} disabled={loading}>
          Forgot Password
        </Button>
        <Typography mt={2}>
          Go to{" "}
          <Link to="/login">
            <span style={{ textDecoration: "outlined", cursor: "pointer" }}>
              Login
            </span>
          </Link>
        </Typography>
      </Box>
    </Box>
  );
};

export default ForgotPassword;
