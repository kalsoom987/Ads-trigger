import { create } from "zustand";

export const useResultStore = create((set) => ({
  ytResults: [],
  setYtResults: (data) => {
    set({ ytResults: data });
  },
  googleResult: [],
  setGoogleResults: (data) => {
    set({ googleResult: data });
  },
  keywordResults: [],
  setKeywordResults: (data) => {
    set({ keywordResults: data });
    // console.log("Keywords data", data);
  },
  questions: [],
  setQuestions: (data) => {
    set({ questions: data });
    // console.log("Questions", data);
  },
  loading: false,
  setLoading: (res) => {
    set({ loading: res });
  },
  clicked: false,
  setClicked: (res) => {
    set({ clicked: true });
  },
}));
