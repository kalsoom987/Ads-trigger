import { useEffect, useState } from "react";
import "react-toastify/dist/ReactToastify.css";
import { Routes, Route, useLocation } from "react-router-dom";
import { useUserStore } from "./store/user";

// Pages
import Home from "./pages/Home";
import Updates from "./pages/Updates";
import Contact from "./pages/Contact";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import { onAuthStateChanged } from "firebase/auth";
import { auth, db } from "./firebaseConfig";
import { addDoc, collection, getDocs, doc, getDoc } from "firebase/firestore";

import VerifyEmail from "./pages/VerifyEmail";
import UserProfile from "./pages/UserProfile";
import ProtectedRoute from "./components/ProtectedRoute";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import CookiePolicy from "./pages/CookiePolicy";
import ForgotPassword from "./pages/ForgotPassword";

// App functional Component
function App() {
  const user = useUserStore((state) => state.user);
  const setUser = useUserStore((state) => state.setUser);
  const setIp = useUserStore((state) => state.setIp);

  const getIpAddress = () => {
    // fetching api address of the user
    fetch("https://api.ipify.org/?format=json")
      .then((res) => res.json())
      .then((data) => {
        console.log(data); // api response
        const collectionRef = collection(db, "ips");
        let flag = false;
        getDocs(collectionRef).then((querySnapshot) => {
          // checking if ip already exists in db
          querySnapshot.forEach((doc) => {
            if (doc.data().ip === data.ip) {
              console.log("ip already exists");
              setIp({ ...doc.data(), id: doc.id });
              flag = true;
              return;
            }
          });
          // if ip not exists in db then create add it
          if (!flag) {
            const ipObj = {
              ip: data.ip,
              searchCount: 0,
            };
            addDoc(collectionRef, ipObj).then((res) => {
              console.log("ip added");
              setIp(ipObj);
            });
          }
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // onAuthStateChanged(auth, (user) => {
  //   if (user) {
  //     console.log("user logged in");
  //     console.log(user);
  //     setUser(user);
  //   } else {
  //     setUser(null);
  //   }
  // });

  useEffect(() => {
    getIpAddress();
    if (JSON.parse(localStorage.getItem("token"))) {
      console.log("token exit");
      const docRef = doc(
        db,
        "users",
        JSON.parse(localStorage.getItem("token")).token
      );
      getDoc(docRef)
        .then((doc) => {
          if (doc.exists()) {
            console.log("Document data:", { ...doc.data(), id: doc.id });
            setUser({ ...doc.data(), id: doc.id });
          } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
          }
        })
        .catch((error) => {
          console.log("Error getting document:", error);
        });
    }
  }, []);

  function ScrollToTopOnRouteChange() {
    const { pathname } = useLocation();

    useEffect(() => {
      window.scrollTo(0, 0);
    }, [pathname]);

    return null;
  }

  return (
    <>
      <ScrollToTopOnRouteChange />
      <Routes>
        {/* {!user ? ( //?.emailVerified
          <>
            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<SignUp />} />
            <Route path="/verify" element={<VerifyEmail />} />
            <Route path="*" element={<h1>Not Found</h1>} />
          </>
        ) : (
          <> */}
        {/* <Route path="/login" element={<Navigate to="/" replace />} />
            <Route path="/signup" element={<Navigate to="/" replace />} /> */}
        <Route path="/" element={<Home />} />
        <Route path="/updates" element={<Updates />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/profile" element={<UserProfile />} />
        <Route path="/login" element={<ProtectedRoute Component={Login} />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/verify" element={<VerifyEmail />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/cookie" element={<CookiePolicy />} />
        <Route path="*" element={<h1>Not Found</h1>} />
        {/* </> */}
        {/* )} */}
      </Routes>
    </>
  );
}

export default App;
