export const colors = {
  backGround: "#ebebef",
  primary: "#0097b2",
  secondary: "#fabc00",
  gray: "#cfd8dc",
};
