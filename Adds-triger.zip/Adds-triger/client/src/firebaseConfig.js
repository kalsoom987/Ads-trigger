// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD3TcXIzQ0lngI6uFrJAPKbQfkIR3T8NYY",
  authDomain: "adtriggers-9af44.firebaseapp.com",
  projectId: "adtriggers-9af44",
  storageBucket: "adtriggers-9af44.appspot.com",
  messagingSenderId: "738752331946",
  appId: "1:738752331946:web:af19b98180ea1a391050d3",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
