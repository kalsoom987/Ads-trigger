import React from "react";
import styles from "./Pricing.module.css";
import { colors } from "../../assets/colors";
import cardImage from "../../assets/clouds.png";
// import ButtonPricing from "../Button_pricing/ButtonPricing";
import { useUserStore } from "../../store/user";
import { Button, Modal, Box, Typography } from "@mui/material";
// Firebase imports
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../../firebaseConfig";
import { toast } from "react-toastify";

import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import CheckoutForm from "../CheckoutForm/CheckoutForm";
import { useParams } from "react-router-dom";

// const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLIC_KEY);
const stripePromise = loadStripe("pk_live_99zG3ictBnaBVgUyv8RbpUvL");

const options = {
  mode: "payment",
  amount: 900,
  currency: "usd",
  // Fully customizable with appearance API.
  appearance: {
    theme: "flat",
    variables: { colorPrimaryText: "#262626" },
  },
};

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 4,
};

const Pricing = () => {
  const user = useUserStore((state) => state.user);
  const setUser = useUserStore((state) => state.setUser);

  const [loading, setLoading] = React.useState(false);

  const [open, setOpen] = React.useState(false);
  const [open2, setOpen2] = React.useState(false);
  const [open3, setOpen3] = React.useState(false);

  const handleOpen = () => setOpen(true);
  const handleOpen2 = () => setOpen2(true);
  const handleOpen3 = () => setOpen3(true);

  const handleClose = () => {
    setOpen(false);
    setOpen2(false);
    setOpen3(false);
  };

  const subscribeDaily = () => {
    // console.log("subscribeDaily");
    if (!user) {
      toast.error("Please login first");
      return;
    }
    setLoading(true);
    const docRef = doc(db, "users", user?.id);
    const startDate = new Date();
    const expiryDate = new Date(
      startDate.getTime() + 24 * 60 * 60 * 1000
    ).toUTCString();

    updateDoc(docRef, {
      ...user,
      membership: "daily",
      searchCount: 0,
      startDate,
      expiryDate,
    })
      .then(() => {
        setUser({
          ...user,
          membership: "daily",
          searchCount: 0,
          startDate,
          expiryDate,
        });
        toast.success("Daily membership activated");
        setLoading(false);
        handleClose();
      })
      .catch((error) => {
        console.log("error in daily membership", error);
        setLoading(false);
      });
  };

  const subscribeMonthly = () => {
    if (!user) {
      toast.error("Please login first");
      return;
    }
    // console.log("subscribeMonthly");
    setLoading(true);
    const docRef = doc(db, "users", user?.id);
    const startDate = new Date();
    const expiryDate = new Date(
      startDate.getTime() + 30 * 24 * 60 * 60 * 1000
    ).toUTCString();

    updateDoc(docRef, {
      ...user,
      membership: "monthly",
      searchCount: 0,
      startDate,
      expiryDate,
    })
      .then(() => {
        setUser({
          ...user,
          membership: "monthly",
          searchCount: 0,
          startDate,
          expiryDate,
        });
        toast.success("Monthly membership activated");
        setLoading(false);
        handleClose();
      })
      .catch((error) => {
        console.log("error in monthly membership", error);
        setLoading(false);
      });
  };

  const subscribeYearly = () => {
    if (!user) {
      toast.error("Please login first");
      return;
    }
    // console.log("subscribeYearly");
    setLoading(true);
    const docRef = doc(db, "users", user?.id);
    const startDate = new Date();
    const expiryDate = new Date(
      startDate.getTime() + 365 * 24 * 60 * 60 * 1000
    ).toUTCString();

    updateDoc(docRef, {
      ...user,
      membership: "yearly",
      searchCount: 0,
      startDate,
      expiryDate,
    })
      .then(() => {
        setUser({
          ...user,
          membership: "yearly",
          searchCount: 0,
          startDate,
          expiryDate,
        });
        toast.success("Yearly membership activated");
        setLoading(false);
        handleClose();
      })
      .catch((error) => {
        console.log("error in yearly membership", error);
        setLoading(false);
      });
  };

  return (
    <>
      <Box
        width={{ xs: "95%", md: "70%", xl: "60%" }}
        id="pricing"
        className={styles.pricing_section}
        marginTop={{ xs: 10, md: 16 }}
      >
        <Box>
          <Typography
            fontSize={{ xs: 30, md: 40 }}
            fontWeight={"bold"}
            color={"primary"}
            textAlign={"center"}
            variant="h1"
          >
            Benefit in the beta phase
          </Typography>
          <Typography
            fontSize={{ xs: 19, md: 23 }}
            color={"primary"}
            textAlign={"center"}
            marginTop={5}
          >
            We are currently in the beta phase. In this period we give big
            discount. With the annual offer you get a special supporter bonus.
          </Typography>
        </Box>
        <div className={styles.pricing_cards} id="pricingCards">
          <div>
            <h1>24 Hours</h1>
            <h2>max 10 analyses</h2>
            <img
              className={styles.cardImage}
              width={224}
              src={cardImage}
              alt="____________"
            />
            <div className={styles.card_details}>
              <div>
                <div className={styles.price}>9.00$</div>
                <div>instead of 18.00$</div>
                <div style={{ fontSize: 14, marginTop: 10 }}>
                  Unlimited access for 24 hours, with a maximum of 10 analyses.
                </div>
              </div>
              <button
                disabled={loading}
                className={styles.pricingButton}
                onClick={handleOpen}
                style={{
                  ...(loading && {
                    backgroundColor: "gray",
                    borderColor: "gray",
                    color: "lightgray",
                  }),
                }}
              >
                Start Now
              </button>
              <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
              >
                <Box sx={style}>
                  <Elements stripe={stripePromise} options={options}>
                    <CheckoutForm
                      cb={subscribeDaily}
                      membership="basic"
                      loading={loading}
                      setLoading={setLoading}
                    />
                  </Elements>
                </Box>
              </Modal>
            </div>
          </div>
          <div>
            <h1>Monthly</h1>
            <h2>max 40 analyses</h2>
            <img
              className={styles.cardImage}
              width={224}
              src={cardImage}
              alt="____________"
            />
            <div className={styles.card_details}>
              <div>
                <div className={styles.price}>29.00$</div>
                <div>instead of 58.00$</div>
                <div style={{ fontSize: 14, marginTop: 10 }}>
                  Unlimited access per month, with a maximum of 40 analyses.
                </div>
              </div>
              <button onClick={handleOpen2} className={styles.pricingButton}>
                Start Now
              </button>
              <Modal
                open={open2}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
              >
                <Box sx={style}>
                  <Elements stripe={stripePromise} options={options}>
                    <CheckoutForm
                      cb={subscribeMonthly}
                      membership="standard"
                      loading={loading}
                      setLoading={setLoading}
                    />
                  </Elements>
                </Box>
              </Modal>
            </div>
          </div>
          <div className={styles.pricing_container}>
            <h1>Annual</h1>
            <h2>max 365 analyses</h2>
            <img
              className={styles.cardImage}
              width={224}
              src={cardImage}
              alt="____________"
            />
            <div className={styles.card_details}>
              <div>
                <div className={styles.price}>197.00$</div>
                <div>instead of 500.00$</div>
                <div style={{ fontSize: 14, marginTop: 10 }}>
                  Unlimited access per year, with a maximum of 365 analyses.
                </div>
              </div>
              {/* <div style={{ display: "flex", justifyContent: "center" }}>
                <ul>
                  <li>all Trigger-Cards</li>
                  <li>all results</li>
                  <li>supporter bonus</li>
                </ul>
              </div> */}
              <button onClick={handleOpen3} className={styles.pricingButton}>
                Start Now
              </button>
              <Modal
                open={open3}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
              >
                <Box sx={style}>
                  <Elements stripe={stripePromise} options={options}>
                    <CheckoutForm
                      cb={subscribeYearly}
                      membership="premium"
                      loading={loading}
                      setLoading={setLoading}
                    />
                  </Elements>
                </Box>
              </Modal>
            </div>
          </div>
        </div>
      </Box>
    </>
  );
};

export default Pricing;
