import React, { useEffect } from "react";
import { useUserStore } from "../store/user";
import { useNavigate } from "react-router-dom";

const ProtectedRoute = ({ Component }) => {
  const user = useUserStore((state) => state.user);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      console.log("user exists protected");
      navigate("/");
    }
  }, []);

  return <Component />;
};

export default ProtectedRoute;
