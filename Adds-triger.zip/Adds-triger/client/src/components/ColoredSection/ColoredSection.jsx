import React from "react";
import { Box, Typography } from "@mui/material";
import { colors } from "../../assets/colors";
import audience from "../../assets/10.1.png";
import styles from "../Footer/Footer.module.css";
const ColoredSection = () => {
  return (
    <Box marginTop={15} textAlign={"center"}>
      <img src={audience} alt="icon" className={styles.img} />
      <Box backgroundColor={colors.primary}>
        <Box
          width={{ xs: "95%", sm: "90%", md: "70%", xl: "60%" }}
          marginX={"auto"}
          paddingY={10}
          paddingX={1}
        >
          <Typography
            color={"white"}
            fontWeight={"bold"}
            fontSize={{ xs: 25, md: 30 }}
          >
            With one click, to all relevant target group segments
          </Typography>
          <Typography
            color={"white"}
            fontSize={{ xs: 17, md: 20 }}
            marginTop={3}
          >
            ADTRIGGERS shows you all relevant website URLs, keywords or YouTube
            videos for your target group setting in Google Ads with one click.
            Forget the manual and tedious work of target group research and
            increase the performance of your Google Ads ads with
            AD-TRIGGERS.COM.
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default ColoredSection;
