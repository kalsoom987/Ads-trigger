import { useState } from "react";
import {
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { toast } from "react-toastify";
import stripeLogo from "../../assets/stripe.png";
import { useUserStore } from "../../store/user";
// import { Box } from "@mui/material";

const styleObj = {
  padding: "5px 15px",
  marginTop: "10px",
  backgroundColor: "#4f74a8",
  border: "1px solid #e6e6e6",
  borderRadius: "5px",
  color: "white",
  fontSize: "16px",
  cursor: "pointer",
};

const CheckoutForm = ({ cb, membership, loading, setLoading }) => {
  const user = useUserStore((state) => state.user);
  const stripe = useStripe();
  const elements = useElements();

  const [errorMessage, setErrorMessage] = useState(null);
  // const [processing, setProcessing] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!user) {
      toast.error("Please Login First");
      return;
    }

    if (elements == null) {
      return;
    }

    // Trigger form validation and wallet collection
    const { error: submitError } = await elements.submit();
    if (submitError) {
      // Show error to your customer
      setErrorMessage(submitError.message);
      return;
    }

    setLoading(true);
    try {
      // Create the PaymentIntent and obtain clientSecret from your server endpoint
      const res = await fetch(`https://adds-trigger.vercel.app/${membership}`, {
        method: "GET",
      });

      const { client_secret: clientSecret } = await res.json();

      const { error, paymentIntent } = await stripe.confirmPayment({
        //`Elements` instance that was used to create the Payment Element
        elements,
        clientSecret,
        confirmParams: {
          return_url: "http://localhost:5173",
        },
        redirect: "if_required",
      });

      if (error) {
        // This point will only be reached if there is an immediate error when
        // confirming the payment. Show error to your customer (for example, payment
        // details incomplete)
        setErrorMessage(error.message);
        setLoading(false);
      } else if (paymentIntent && paymentIntent.status === "succeeded") {
        cb();
      } else {
        // Your customer will be redirected to your `return_url`. For some payment
        // methods like iDEAL, your customer will be redirected to an intermediate
        // site first to authorize the payment, then redirected to the `return_url`.
        setErrorMessage("Something went wrong");
        setLoading(false);
      }
    } catch (err) {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* <Box marginX={"auto"}> */}
      <img src={stripeLogo} alt="" width={100} />
      {/* </Box> */}

      <PaymentElement />
      <button
        style={
          loading
            ? { ...styleObj, opacity: 0.6, cursor: "not-allowed" }
            : styleObj
        }
        type="submit"
        disabled={!stripe || !elements}
      >
        {loading ? "Processing..." : "Pay"}
      </button>
      {/* Show error message to your customers */}
      {errorMessage && <div>{errorMessage}</div>}
    </form>
  );
};

export default CheckoutForm;
