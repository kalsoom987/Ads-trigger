import React, { useState } from "react";
import { Link } from "react-router-dom";
import styles from "./Navbar.module.css";
import MenuIcon from "@mui/icons-material/Menu";
import { auth } from "../../firebaseConfig";
import { useTheme } from "@mui/material/styles";
import {
  Collapse,
  Box,
  IconButton,
  MenuItem,
  Menu,
  Typography,
} from "@mui/material";
import hamburger from "../../assets/hamberger.jpeg";
import { signOut } from "@firebase/auth";
import { toast } from "react-toastify";
import { useUserStore } from "../../store/user";

const Navbar = () => {
  const user = useUserStore((state) => state.user);
  const setUser = useUserStore((state) => state.setUser);

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleMenu = (event) => {
    console.log("Menu clicked");
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const theme = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const handleClick = () => {
    console.log("Burger clicked");
    setIsOpen(!isOpen);
  };

  //  style for Links
  const linkStyle = {
    color: "inherit",
    textDecoration: "none",
  };

  // scroll to pricing section
  const scrollToPricing = () => {
    const pricing = document.getElementById("pricing");
    if (pricing) {
      pricing.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <header className={styles.header}>
        <Box
          display={"flex"}
          justifyContent={"flex-end"}
          alignItems={"center"}
          width={{ xs: "95%", xl: "60%" }}
        >
          {/* <nav className={styles.nav}>
            <div className={styles.dropdown}>
              <ul>
                <Link to="/" style={linkStyle}>
                  <li>Home </li>
                </Link>
                <Link to="#pricing" style={linkStyle} onClick={scrollToPricing}>
                  <li>Go Premium</li>
                </Link>
                <Link to="/updates" style={linkStyle}>
                  <li>Updates</li>
                </Link>
                <Link to="/contact" style={linkStyle}>
                  <li>Contact</li>
                </Link>
                {user ? (
                  <Link to="/profile" style={linkStyle}>
                    <li>Profile</li>
                  </Link>
                ) : (
                  <Link to="/login" style={linkStyle}>
                    <li>Login</li>
                  </Link>
                )}
              </ul>
            </div>
          </nav> */}
          <Typography
            color={"primary"}
            fontSize={20}
            fontWeight={"bold"}
            mr={2}
          >
            Menu
          </Typography>
          <IconButton onClick={handleMenu}>
            <MenuIcon fontSize="large" sx={{ color: "#0097b2" }} />
          </IconButton>
          <Menu
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            transformOrigin={{ horizontal: "right", vertical: "top" }}
            anchorOrigin={{ horizontal: "left", vertical: "bottom" }}
            PaperProps={{ sx: { width: "100%", maxWidth: "160px" } }}
          >
            <MenuItem onClick={handleClose}>
              <Link to="/" style={linkStyle}>
                Home
              </Link>
            </MenuItem>
            <MenuItem onClick={handleClose}>
              <Link to="#pricing" style={linkStyle} onClick={scrollToPricing}>
                Pricing
              </Link>
            </MenuItem>
            <MenuItem onClick={handleClose}>
              <Link to="/updates" style={linkStyle}>
                Updates
              </Link>
            </MenuItem>
            <MenuItem onClick={handleClose}>
              <Link to="/contact" style={linkStyle}>
                Contact
              </Link>
            </MenuItem>
            <MenuItem onClick={handleClose}>
              {user ? (
                <Link to="/profile" style={linkStyle}>
                  <li>Profile</li>
                </Link>
              ) : (
                <Link to="/login" style={linkStyle}>
                  <li>Login</li>
                </Link>
              )}
            </MenuItem>
          </Menu>
        </Box>
        {/* <Box display={{ xs: "block", sm: "none" }}>
          <nav className={styles.nav}>
            <div className={styles.dropdown}>
              <MenuIcon
                onClick={handleClick}
                sx={{
                  marginLeft: "1rem",
                }}
              />
              <Collapse in={isOpen} timeout="auto" unmountOnExit>
                <div
                  className={styles.dropdownContent}
                  sx={{
                    height: "200px",
                    transition: "height 0.3s ease",
                  }}
                >
                  <ul>
                    <Link to="/" style={linkStyle} onClick={handleClick}>
                      <li>Home </li>
                    </Link>
                    <Link to="#pricing" style={linkStyle} onClick={handleClick}>
                      <li>Go Premium</li>
                    </Link>
                    <Link to="/updates" style={linkStyle} onClick={handleClick}>
                      <li>Updates</li>
                    </Link>
                    <Link to="/contact" style={linkStyle} onClick={handleClick}>
                      <li>Contact</li>
                    </Link>
                    {user ? (
                      <Link to="/profile" style={linkStyle}>
                        <li>Profile</li>
                      </Link>
                    ) : (
                      <Link to="/login" style={linkStyle}>
                        <li>Login</li>
                      </Link>
                    )}
                  </ul>
                </div>
              </Collapse>
            </div>
          </nav>
        </Box> */}
      </header>
    </>
  );
};

export default Navbar;
