import { React, useState } from "react";
import footerImg from "../../assets/10.1.png";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";
import { colors } from "../../assets/colors";

const Footer = () => {
  const [isHover, setIsHover] = useState(false);

  return (
    <>
      <footer>
        <img className={styles.img} src={footerImg} alt="" />
        <div
          className={styles.footer}
          style={{ backgroundColor: colors.primary }}
        >
          <div className={styles.lower_footer}>
            <h1>
              <span style={{ color: colors.gray }}>AD</span>TRIGGERS
            </h1>
            <div className={styles.lower_footer_grid}>
              <div className={styles.item_1}>
                <h2>Contact</h2>
                <p>Saleway GmbH</p>
                <p>Schulhausgässli 4</p>
                <p>3098 Köniz</p>
                <p>CH-Bern</p>
                <li style={{ marginTop: 24 }}>
                  <Link
                    style={{
                      color: colors.backGround,
                      textDecoration: "none",
                    }}
                    to="mailto:info@ad-triggers.com"
                  >
                    info@ad-triggers.com
                  </Link>
                </li>
              </div>
              <div className={styles.item_2}>
                <h2>Menu</h2>
                <li style={{ marginTop: 6 }}>
                  <Link
                    style={{
                      color: colors.backGround,
                      textDecoration: "none",
                    }}
                    to="/"
                  >
                    Home
                  </Link>
                </li>
                <li style={{ marginTop: 3, marginBottom: 24 }}>
                  <a
                    style={{
                      color: colors.backGround,

                      textDecoration: "none",
                    }}
                    href="#pricing"
                  >
                    Price
                  </a>
                </li>
              </div>
              <div className={styles.item_3}>
                <h2>Account</h2>
                <li style={{ marginTop: 6 }}>
                  <Link
                    style={{
                      color: colors.backGround,
                      textDecoration: "none",
                    }}
                    to="/login"
                  >
                    Login
                  </Link>
                </li>
                <li style={{ marginTop: 3, marginBottom: 24 }}>
                  <Link
                    style={{
                      color: colors.backGround,

                      textDecoration: "none",
                    }}
                    to="/signup"
                  >
                    Registration
                  </Link>
                </li>
              </div>
              <div className={styles.item_4}>
                <h2>Various</h2>
                <li style={{ marginTop: 6 }}>
                  <Link
                    style={{
                      color: colors.backGround,
                      textDecoration: "none",
                    }}
                    to="/privacy-policy"
                  >
                    Privacy
                  </Link>
                </li>
                <li style={{ marginTop: 3 }}>
                  <Link
                    style={{
                      color: colors.backGround,
                      textDecoration: "none",
                    }}
                    to="/cookie"
                  >
                    Cookie Policy
                  </Link>
                </li>
                <li style={{ marginTop: 3 }}>
                  <Link
                    style={{
                      color: colors.backGround,
                      textDecoration: "none",
                    }}
                    to="/imprint"
                  >
                    Imprint
                  </Link>
                </li>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
