import React from "react";
import { Box, Typography } from "@mui/material";
import { colors } from "../../assets/colors";
import yt1 from "../../assets/youtube.png";
import web from "../../assets/website.png";
import keyword from "../../assets/keyword.png";

const CardsDetail = () => {
  return (
    <Box backgroundColor={colors.primary} marginTop={15}>
      <Box
        width={{ xs: "95%", sm: "90%", md: "70%", xl: "60%" }}
        marginX={"auto"}
        textAlign={{ xs: "center", md: "left" }}
        paddingY={10}
      >
        <TwoParts
          title="YouTube"
          text="The YouTube Trigger is ideal for creating a Google Ads target group with YouTube video url. Your campaign will be triggered as soon as someone watches one of the defined or similar videos."
          image={yt1}
          divider
        />

        <TwoParts
          title="website URL"
          text="The website URL trigger card is ideal for creating a Google Ads target group with relevant websites. Thus, your campaign will be triggered as soon as someone looks at one of the defined or similar websites."
          image={web}
          divider
        />
        <TwoParts
          title="Keyword"
          text="The Keywords Trigger Card is ideal for creating a Google Ads target group with relevant keywords (search terms). So your campaign will be triggered as soon as someone searches with one of the keywords on Google."
          image={keyword}
        />
      </Box>
    </Box>
  );
};

export default CardsDetail;

const TwoParts = ({ title, text, image, divider }) => {
  return (
    <Box>
      <Box
        display={"flex"}
        flexDirection={{ xs: "column", md: "row" }}
        alignItems={"center"}
      >
        <Box>
          <img src={image} alt="card" style={{ width: "200px" }} />
        </Box>
        <Box paddingLeft={{ xs: 0, md: 5, lg: 10 }} mt={{ xs: 4, md: 0 }}>
          <Typography
            fontSize={{ xs: 25, sm: 28, lg: 35 }}
            color={"white"}
            fontWeight={"600"}
            gutterBottom
          >
            {`The ${title} Trigger`}
          </Typography>
          <Typography color={"white"} fontSize={{ xs: 17, md: 19 }}>
            {text}
          </Typography>
        </Box>
      </Box>
      <Example />
      {divider && (
        <Box
          width={{ xs: "100%", md: "80%" }}
          height={5}
          marginX={"auto"}
          marginY={15}
          backgroundColor={"white"}
        ></Box>
      )}
    </Box>
  );
};

const Example = () => {
  return (
    <Box marginTop={5}>
      <Typography color={"white"} fontWeight={"500"}>
        Example:
      </Typography>
      <Typography color={"white"} fontSize={{ xs: 17, md: 19 }}>
        You sell healthy and grain-free dog food. Thanks to ADTRIGGERS you can
        now create a target group with all important website about "healthy dog
        food". As soon as someone visits one of the websites, they will be
        tracked with your advertising.
      </Typography>
    </Box>
  );
};
