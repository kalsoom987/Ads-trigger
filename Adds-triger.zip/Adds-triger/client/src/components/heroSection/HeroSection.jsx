import { Box, Typography } from "@mui/material";

// MUI icons
import YouTubeIcon from "@mui/icons-material/YouTube";
import GoogleIcon from "@mui/icons-material/Google";

import { colors } from "../../assets/colors";

import Search from "../results/Search";

const HeroSection = () => {
  return (
    <Box
      width={{ xs: "95%", md: "85%", xl: "60%" }}
      marginX={"auto"}
      marginTop={16}
      position={"relative"}
    >
      <Box textAlign={"center"} padding={2}>
        <Typography
          color={colors.gray}
          fontSize={{ xs: 30, md: 58 }}
          fontWeight={"bold"}
          display={"flex"}
          alignItems={"center"}
          justifyContent={"center"}
        >
          <span style={{ color: colors.primary }}>AD</span>TRIGGERS
          <span
            style={{
              fontSize: "30px",
              marginLeft: "26px",
              marginTop: "5px",
              display: "flex",
              alignItems: "center",
            }}
          >
            V1.3 <YouTubeIcon className="icon" />{" "}
            <GoogleIcon className="icon" />
          </span>
        </Typography>
        <Typography fontSize={{ xs: 25, md: 40 }} color={colors.gray}>
          The OneKlick Google Ads Audience Generator
        </Typography>
      </Box>
    </Box>
  );
};

export default HeroSection;
