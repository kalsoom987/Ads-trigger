import React from "react";
import styles from "../Pricing/Pricing.module.css";
import { colors } from "../../assets/colors";

// import styles from "../Pricing.module.css";
const ButtonPricing = () => {
  return (
    <>
      <button className={styles.pricingButton}>Start Now</button>
    </>
  );
};
export default ButtonPricing;
