import React from "react";
import { Box, Typography } from "@mui/material";
import { colors } from "../../assets/colors";

const TextSection = () => {
  return (
    <Box
      marginTop={15}
      width={{ xs: "95%", sm: "90%", md: "70%", xl: "60%" }}
      marginX={"auto"}
    >
      <Typography
        color={"primary"}
        gutterBottom
        fontSize={{ xs: 25, sm: 30, md: 35, lg: 40 }}
        fontWeight={"bold"}
        lineHeight={1.2}
      >
        With AdTriggers perfect target group and better performance with Google
        Ads
      </Typography>

      <Box marginTop={8}>
        <Typography
          color={"GrayText"}
          fontSize={{ xs: 18, sm: 20 }}
          marginY={3}
        >
          A trigger is nothing but a trigger. In the Google Ads area, it is
          defined when the advertising should be triggered for a target group
          with keywords, website URLs, custom segments or apps.
        </Typography>
        <Typography
          color={"GrayText"}
          fontSize={{ xs: 18, sm: 20 }}
          marginY={3}
        >
          If I say, for example, that if someone searches for a specific or
          similar website like XY or with a specific keyword on Google, the the
          advertising will be played out if the behavior is defined accordingly.
        </Typography>
        <Typography
          color={"GrayText"}
          fontSize={{ xs: 18, sm: 20 }}
          marginY={3}
        >
          The Trigger Cards are nothing more than collections or groupings of
          trigger types like website URL. For example, with the trigger card
          website URLs, all relevant website URLs that match your topic are
          displayed.
        </Typography>
        <Typography
          color={"GrayText"}
          fontSize={{ xs: 18, sm: 20 }}
          marginY={3}
        >
          In the beta phase we start with the 3 most important trigger cards.
          These include website URL, YouTube video URL or Keywords. We will then
          continuously develop furthur relevant trigger cards and make them
        </Typography>
      </Box>
    </Box>
  );
};

export default TextSection;
