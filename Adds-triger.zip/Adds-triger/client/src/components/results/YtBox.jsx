// import React from "react";
import { useResultStore } from "../../store/store";
import {
  Box,
  Typography,
  IconButton,
  Tooltip,
  Skeleton,
  Checkbox,
} from "@mui/material";
import { colors } from "../../assets/colors";
import DeleteIcon from "@mui/icons-material/Delete";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { useState } from "react";

const YtBox = ({ tags }) => {
  const [copied, setCopied] = useState(false);
  const loading = useResultStore((state) => state.loading);
  const ytResults = useResultStore((state) => state.ytResults);
  const setYtResults = useResultStore((state) => state.setYtResults);

  // Copy to clipboard function
  const copyToClipBoard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, [500]);
  };

  // Checkbox Change
  const checkboxChange = (id, check) => {
    let copyArr = [...ytResults];
    copyArr = copyArr.map((item, i) => {
      if (item?.id === id) {
        return { ...item, isChecked: check };
      }
      return item;
    });
    // console.log(copyArr, "firstArr");
    setYtResults(copyArr);
  };

  // Filtering Array based on tags
  const filteredArr = ytResults.filter(({ description }) => {
    if (tags.length === 0) {
      return true;
    }
    // return tags.some((tag) => description.includes(tag.text));
    let flag = true;
    for (let i = 0; i < tags.length; i++) {
      if (!description?.toLowerCase().includes(tags[i].text?.toLowerCase())) {
        flag = false;
        break;
      }
    }
    return flag;
  });

  return loading ? (
    <Box height={600}>
      <Skeleton
        className="transOrigin"
        height={"100%"}
        width={"100%"}
        animation={"wave"}
      />
    </Box>
  ) : filteredArr.length > 0 ? (
    <Box
      border={2}
      borderColor={"lightgray"}
      borderRadius={2}
      height={"100%"}
      marginTop={5}
      display={"flex"}
    >
      <Box padding={2} flex={{ xs: 1, md: 0.5, xl: 0.4 }}>
        {filteredArr.map((item, i) => (
          <Typography
            key={item?.id}
            fontSize={16}
            mb={1}
            sx={{
              display: "flex",
              justifyContent: "space-between",
              borderBottom: 1,
              borderColor: colors.gray,
              alignItems: "center",
            }}
          >
            <Box display={"flex"}>
              <span
                style={{
                  color: colors.gray,
                  fontWeight: "bold",
                  marginRight: 8,
                }}
              >
                {i + 1}{" "}
              </span>
              <Box
                display={{ xs: "block", sm: "none", md: "block" }}
                color={colors.gray}
              >
                {item?.url?.length > 36
                  ? `${item.url.slice(0, 30)}...`
                  : item?.url}
              </Box>
              <Box
                display={{ xs: "none", sm: "block", md: "none" }}
                color={colors.gray}
              >
                {item?.url?.length > 46
                  ? `${item.url.slice(0, 45)}...`
                  : item?.url}
              </Box>
            </Box>
            <Box>
              <Tooltip title={copied && "copied"} placement="top">
                <IconButton
                  sx={{ padding: "3px" }}
                  onClick={() => copyToClipBoard(item.url)}
                >
                  <ContentCopyIcon sx={{ fontSize: 18 }} />
                </IconButton>
              </Tooltip>
              <Checkbox
                checked={item?.isChecked}
                size="small"
                onChange={() => checkboxChange(item?.id, !item?.isChecked)}
              />
            </Box>
          </Typography>
        ))}
      </Box>
      <Box
        height={"auto"}
        borderLeft={2}
        borderColor={"lightgray"}
        flex={{ md: 0.5, lg: 0.6 }}
        padding={2}
        display={{ xs: "none", md: "block" }}
      >
        {filteredArr?.map((item, i) => (
          <Typography key={item?.id} fontSize={15} color={colors.gray}>
            {item?.description}
          </Typography>
        ))}
      </Box>
    </Box>
  ) : (
    <Typography fontSize={23} mt={3}>
      No Results Found!
    </Typography>
  );
};

export default YtBox;
