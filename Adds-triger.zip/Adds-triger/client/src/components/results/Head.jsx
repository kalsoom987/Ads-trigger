import React, { useState } from "react";
import FileCopyOutlinedIcon from "@mui/icons-material/FileCopyOutlined";
import { WithContext as ReactTags } from "react-tag-input";
import { Box, IconButton, Tooltip, Typography } from "@mui/material";
import { useResultStore } from "../../store/store";
import { colors } from "../../assets/colors";

const KeyCodes = {
  comma: 188,
  enter: 13,
};

const delimiters = [KeyCodes.comma, KeyCodes.enter];

const textObj = {
  YouTube: "Title",
  Website: "URL",
  Keywords: "Keyword",
  Questions: "Title",
};

const Head = ({ tags, setTags, active }) => {
  const [copied, setCopied] = useState(false);
  // Getting All the results arrays from store
  const ytResults = useResultStore((state) => state.ytResults);
  const googleResults = useResultStore((state) => state.googleResult);
  const keywordResults = useResultStore((state) => state.keywordResults);
  const questions = useResultStore((state) => state.questions);

  const handleDelete = (i) => {
    setTags(tags.filter((tag, index) => index !== i));
  };

  const handleAddition = (tag) => {
    setTags([...tags, tag]);
  };

  const handleDrag = (tag, currPos, newPos) => {
    const newTags = tags.slice();

    newTags.splice(currPos, 1);
    newTags.splice(newPos, 0, tag);

    // re-render
    setTags(newTags);
  };

  const handleTagClick = (index) => {
    console.log("The tag at index " + index + " was clicked");
  };

  // Funtion to copy all the content
  const copyAllContent = () => {
    let arrayToCopy =
      active === "YouTube"
        ? ytResults
        : active === "Website"
        ? googleResults
        : active === "Keywords"
        ? keywordResults
        : active === "Questions"
        ? questions
        : null;

    if (active === "YouTube") {
      let filteredArr = arrayToCopy.filter(({ description, isChecked }) => {
        if (tags.length === 0) {
          return isChecked;
        }
        // return tags.some((tag) => description.includes(tag.text) && isChecked);
        let flag = true;
        for (let i = 0; i < tags.length; i++) {
          if (
            !description?.toLowerCase().includes(tags[i].text?.toLowerCase()) ||
            !isChecked
          ) {
            flag = false;
            break;
          }
        }
        return flag;
      });
      filteredArr = filteredArr.map((item) => item.url);
      // Copy text to the clipboard
      const textCopy = filteredArr.join("\n");
      navigator.clipboard.writeText(textCopy);
    } else {
      // Filtering Array based on tags
      let filteredArr = arrayToCopy.filter(({ data, isChecked }) => {
        if (tags.length === 0) {
          return isChecked;
        }
        // return tags.some((tag) => data.includes(tag.text) && isChecked);
        let flag = true;
        for (let i = 0; i < tags.length; i++) {
          if (
            !data?.toLowerCase().includes(tags[i].text?.toLowerCase()) ||
            !isChecked
          ) {
            flag = false;
            break;
          }
          console.log("check", !data.includes(tags[i].text) || !isChecked);
        }
        return flag;
      });
      filteredArr = filteredArr?.map((item) => item?.data);
      console.log(filteredArr, "filteredArr");
      // Copy text to the clipboard
      const textCopy = filteredArr.join("\n");
      navigator.clipboard.writeText(textCopy);
    }
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, [600]);
  };

  return (
    <Box
    // marginTop={8}
    // display={"flex"}
    // flexDirection={{ xs: "column", sm: "row" }}
    // justifyContent={{ xs: "center", sm: "space-between" }}
    // alignItems={"center"}
    // textAlign={{ xs: "center", sm: "left" }}
    >
      {/* <Box>
        <Typography
          color={"primary"}
          fontSize={{ xs: 25, md: 30 }}
          fontWeight={"600"}
        >
          <span style={{ color: "#fabc00" }}>{active} </span>
          audience
        </Typography>
      </Box> */}
      <Box
        display={"flex"}
        alignItems={"center"}
        // flex={{ sm: 0.9, md: 0.8, lg: 0.7 }}
      >
        <Typography color={"primary"}>{textObj[active]} contains: </Typography>
        <Box
          flex={{ xs: 1, md: 0.5 }}
          marginX={1}
          backgroundColor={colors.gray}
          paddingY={0.5}
          paddingX={1}
          borderRadius={2}
        >
          <ReactTags
            placeholder="Enter Tags"
            tags={tags}
            delimiters={delimiters}
            handleDelete={handleDelete}
            handleAddition={handleAddition}
            handleDrag={handleDrag}
            handleTagClick={handleTagClick}
            classNames={{ tagInputField: "input" }}
          />
        </Box>
        <Tooltip placement="top" title={copied && "copied"}>
          <IconButton onClick={copyAllContent}>
            <FileCopyOutlinedIcon color="primary" sx={{ cursor: "pointer" }} />
          </IconButton>
        </Tooltip>
      </Box>
    </Box>
  );
};

export default Head;
