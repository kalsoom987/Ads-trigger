import React, { useState } from "react";

// styles (to get same styles as in hero section)
import styles from "../heroSection/HeroSection.module.css";

// MUI imports
import { Box, Button, Typography } from "@mui/material";
import PlayCircleIcon from "@mui/icons-material/PlayCircle";

// import states from store
import { useResultStore } from "../../store/store";
import { useUserStore } from "../../store/user";

// axios
import axios from "axios";

// firebase imports
import { db } from "../../firebaseConfig";
import { doc, updateDoc } from "firebase/firestore";

// uuid
import { v4 as uuid4 } from "uuid";

// toast
import { toast } from "react-toastify";

// colors assests
import { colors } from "../../assets/colors";

// Logins for dataforseo
const login = "webcoach.security@gmail.com";
const password = "ddd80ef47d5b22f5";

const Search = ({ setActive }) => {
  const [keyword, setKeyword] = useState("");
  const [language, setLanguage] = useState("en");

  // states from store
  const loading = useResultStore((state) => state.loading);
  const setLoading = useResultStore((state) => state.setLoading);
  const setClicked = useResultStore((state) => state.setClicked);

  // States for setting results to the store
  const setYtResults = useResultStore((state) => state.setYtResults);
  const setGoogleResult = useResultStore((state) => state.setGoogleResults);
  const setKeywordResults = useResultStore((state) => state.setKeywordResults);
  const setQuestions = useResultStore((state) => state.setQuestions);

  // States from user store
  const user = useUserStore((state) => state.user);
  const setUser = useUserStore((state) => state.setUser);
  const ip = useUserStore((state) => state.ip);
  const setIp = useUserStore((state) => state.setIp);

  // function to set expire the package in DB
  const expirePackage = () => {
    const docRef = doc(db, "users", user?.id);
    updateDoc(docRef, {
      ...user,
      expiryDate: null,
      startDate: null,
      endDate: null,
      searchCount: 3,
      membership: "free",
    })
      .then(() => {
        setUser({
          ...user,
          expiryDate: null,
          searchCount: 3,
          membership: "free",
        });
        console.log("package expired");
      })
      .catch((err) => {
        console.log("error in expiry", err);
      });
  };

  // get Keywords
  const getKeywords = () => {
    console.log("language", language);
    let data = JSON.stringify([
      {
        location_code: 2840,
        keywords: [keyword],
      },
    ]);
    let config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "https://api.dataforseo.com/v3/keywords_data/google_ads/keywords_for_keywords/live",
      headers: {
        "Content-Type": "application/json",
        Authorization:
          "Basic d2ViY29hY2guc2VjdXJpdHlAZ21haWwuY29tOmRkZDgwZWY0N2Q1YjIyZjU=",
      },
      data: data,
    };
    axios
      .request(config)
      .then((response) => {
        // keywords
        const keywordArr = [];
        response?.data?.tasks[0]?.result?.map((keywords) => {
          // console.log("keywords", keywords);
          const keyword = keywords?.keyword;
          if (keyword) {
            const obj = {
              data: keyword,
              isChecked: true,
              id: uuid4(),
            };
            keywordArr.push(obj);
          }
          // console.log("single keyword", keyword);
        });
        // if user is not available or have free membership then show 3 results
        if (!user || user?.membership === "free") {
          setKeywordResults(keywordArr.slice(0, 3));
        } else {
          // setting keywords to the store state
          if (keywordArr.length > 100) {
            setKeywordResults(keywordArr.slice(0, 100));
          } else setKeywordResults(keywordArr);
        }
      })
      .catch((err) => {
        console.log("error in keywords", err);
      });
  };

  // get youtube urls
  const getYoutubeUrls = () => {
    axios({
      method: "post",
      url: "https://api.dataforseo.com/v3/serp/youtube/organic/live/advanced",
      auth: {
        username: login,
        password: password,
      },
      data: [
        {
          keyword: encodeURI(keyword),
          language_code: language,
          location_code: 2840,
          block_depth: 2,
        },
      ],
      headers: {
        "content-type": "application/json",
      },
    })
      .then((response) => {
        const data = response.data.tasks[0].result[0].items;
        const dataArr = data.map((item) => {
          return {
            ...item,
            isChecked: true,
            id: uuid4(),
          };
        });

        // if user is not available or have free membership then show 3 results
        if (!user || user?.membership === "free") {
          setYtResults(dataArr.slice(0, 3));
        } else {
          // setting youtube results to the store state
          setYtResults(dataArr);
        }
      })
      .catch(function (error) {
        console.log(error);
      })
      .finally(() => {
        setKeyword("");
        setLoading(false);
      });
  };

  // Get Youtube URLs and all other results
  const handleClick = () => {
    console.log(ip, "ip");
    console.log(user, "user");
    // if input is empty
    if (!keyword) {
      toast.error("Please enter a keyword");
      return;
    }

    // if user is logged in
    if (user) {
      if (user?.membership === "free" && user?.searchCount >= 3) {
        console.log("free user");
        toast.error(
          "3 results for free! upgrade to premium to get more results"
        );
        return;
      } else if (user?.membership === "daily") {
        console.log("daily user");
        // console.log(user?.expiryDate?.toDate());
        if (
          user?.expiryDate &&
          new Date(user?.expiryDate).toUTCString() < new Date().toUTCString()
        ) {
          expirePackage();
          toast.error("Package has been expired");
          return;
        } else if (user?.searchCount >= 10) {
          toast.error("Your Search limit has been reached");
          return;
        }
      } else if (user?.membership === "monthly") {
        console.log("monthly user");
        if (
          user?.expiryDate &&
          new Date(user?.expiryDate).toUTCString() < new Date().toUTCString()
        ) {
          expirePackage();
          toast.error("Package has been expired");
          return;
        } else if (user?.searchCount >= 40) {
          toast.error("Your Search limit has been reached");
          return;
        }
      } else if (user?.membership === "yearly") {
        console.log("yearly user");
        if (
          user?.expiryDate &&
          new Date(user?.expiryDate).toUTCString() < new Date().toUTCString()
        ) {
          expirePackage();
          toast.error("Package has been expired");
          return;
        } else if (user?.searchCount >= 365) {
          toast.error("Your Search limit has been reached");
          return;
        }
      }

      // resultRef.current.scrollIntoView({ behavior: "smooth" });

      // increase searchCount in user obj
      setLoading(true);
      setClicked(true);
      const docRef = doc(db, "users", user?.id);
      updateDoc(docRef, { ...user, searchCount: user?.searchCount + 1 })
        .then(() => {
          console.log("user searchcount increases");
          setUser({ ...user, searchCount: user?.searchCount + 1 });

          getYoutubeUrls();
          getKeywords();
          getWebsites();
        })
        .catch(() => {
          setLoading(false);
        });
    }

    // if user is not logged in then consider ip address
    else {
      // if ip does not exits
      if (!ip) {
        toast.error("Please wait for 5 seconds and try again");
        return;
      }
      if (ip?.searchCount >= 3) {
        toast.error(
          "3 results for free! upgrade to premium to get more results"
        );
        return;
      }

      // if ip exits and less than 3
      // if (!user) {
      const docRef = doc(db, "ips", ip.id);
      updateDoc(docRef, {
        searchCount: ip.searchCount + 1,
      }).then(() => {
        console.log("search count increased");
        setIp({ ...ip, searchCount: ip.searchCount + 1 });
        setClicked(true);

        setLoading(true);

        getYoutubeUrls();
        getKeywords();
        getWebsites();
      });
      // }
    }
  };

  const getWebsites = () => {
    axios({
      method: "post",
      url: "https://api.dataforseo.com/v3/serp/google/organic/live/advanced",
      auth: {
        username: login,
        password: password,
      },
      data: [
        {
          keyword: encodeURI(keyword),
          language_code: language,
          location_code: 2840,
        },
      ],
      headers: {
        "content-type": "application/json",
      },
    }).then((response) => {
      console.log(typeof response);
      let googleResult = [];
      response.data.tasks[0].result[0].items.map((item) => {
        if (item?.url) {
          // google keyword links
          googleResult.push({ data: item.url, isChecked: true, id: uuid4() });
        }
      });

      // if user is not available or have free membership then show 3 results
      if (!user || user?.membership === "free") {
        setGoogleResult(googleResult.slice(0, 3));
      } else {
        // setting google results to the store
        setGoogleResult(googleResult);
      }

      // google Questions
      const questions = [];
      response.data.tasks[0].result[0].items.map((item, i = 0) => {
        // console.log(item, "questions");
        if (item.title != undefined && item.title != null) {
          questions.push({ data: item.title, isChecked: true, id: uuid4() });
          i++;
        }

        // console.log(questions);
        // setting questions to the store state
        setQuestions(questions);

        // if user is not available then show 3 results
        if (!user || user?.membership === "free") {
          setQuestions(questions.slice(0, 3));
        } else {
          // setting questions to the store state
          setQuestions(questions);
        }
      });
    });
  };

  return (
    <>
      <Box
        height={45}
        border={2}
        borderColor={colors.gray}
        borderRadius={3}
        overflow={"hidden"}
        width={"100%"}
        display={"flex"}
        alignItems={"center"}
      >
        <Box width={"50%"} borderRight={3} borderColor={colors.gray}>
          <input
            type="text"
            placeholder="Keyword"
            className={styles.input}
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
          />
        </Box>

        {/* Language */}
        <Box width={"25%"} borderRight={3} borderColor={colors.gray}>
          <select
            onChange={(e) => setLanguage(e.target.value)}
            className={styles.select}
          >
            <option value="en">English</option>
            <option value="fr">French</option>
            <option value="es">Spanish</option>
            <option value="de">German</option>
          </select>
        </Box>

        {/* Audience */}
        <Box width={"25%"}>
          <select
            onChange={(e) => setActive(e.target.value)}
            className={styles.select}
          >
            <option value="YouTube">YouTube</option>
            <option value="Website">Websites</option>
            <option value="Keywords">Keywords</option>
            <option value="Questions">Questions</option>
          </select>
        </Box>
        <Button onClick={handleClick} disabled={loading} variant="contained">
          start
        </Button>
      </Box>
      {/* Watch video */}
      <Box>
        <Typography
          color={colors.primary}
          display={"flex"}
          alignItems={"center"}
          marginTop={4}
          justifyContent={"flex-end"}
        >
          <PlayCircleIcon />
          <a href="#" style={{ color: colors.primary }}>
            Watch Video
          </a>
        </Typography>
      </Box>
    </>
  );
};

export default Search;
