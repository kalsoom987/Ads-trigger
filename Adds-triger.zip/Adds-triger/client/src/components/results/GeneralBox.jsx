import React from "react";
import { Box, Skeleton, Typography, Checkbox } from "@mui/material";
import { colors } from "../../assets/colors";
import { useResultStore } from "../../store/store";
// import FileCopyOutlinedIcon from "@mui/icons-material/FileCopyOutlined";

const GeneralBox = ({ result, tags, active }) => {
  const loading = useResultStore((state) => state.loading);

  // Getting All the results arrays from store
  const setGoogleResults = useResultStore((state) => state.setGoogleResults);
  const setKeywordResults = useResultStore((state) => state.setKeywordResults);
  const setQuestions = useResultStore((state) => state.setQuestions);

  let copyArr = [...result];

  // Checkbox Change
  const setCheckedArr = (id, check) => {
    if (active === "Website") {
      copyArr = copyArr.map((item, i) => {
        if (item?.id === id) {
          return { ...item, isChecked: check };
        }
        return item;
      });
      // console.log(copyArr, "google");
      setGoogleResults(copyArr);
    } else if (active === "Keywords") {
      let copyArr = [...result];
      copyArr = copyArr.map((item, i) => {
        if (item?.id === id) {
          return { ...item, isChecked: check };
        }
        return item;
      });
      // console.log("keyword", copyArr);
      setKeywordResults(copyArr);
    } else if (active === "Questions") {
      let copyArr = [...result];
      copyArr = copyArr.map((item, i) => {
        if (item?.id === id) {
          return { ...item, isChecked: check };
        }
        return item;
      });
      setQuestions(copyArr);
    }
  };

  // Filtering Array based on tags
  const filteredArr = result.filter((item) => {
    if (tags.length === 0) {
      return true;
    }
    // return tags.some((tag) => item.data.includes(tag.text));
    let flag = true;
    for (let i = 0; i < tags.length; i++) {
      if (!item?.data?.toLowerCase().includes(tags[i].text.toLowerCase())) {
        flag = false;
        break;
      }
    }
    return flag;
  });

  return loading ? (
    <Box>
      <Skeleton
        className="transOrigin"
        height={600}
        width={"100%"}
        animation="wave"
      />
    </Box>
  ) : filteredArr.length > 0 ? (
    <Box
      padding={2}
      // className="overflowY"
      border={2}
      borderColor={"lightgray"}
      borderRadius={2}
      marginTop={5}
      height={"100%"}
    >
      {filteredArr.map((item, i) => (
        <SingleItem
          key={item?.id}
          item={item?.data}
          isChecked={item?.isChecked}
          id={item?.id}
          setCheckedArr={setCheckedArr}
          i={i}
        />
      ))}
    </Box>
  ) : (
    <Typography fontSize={23} mt={3}>
      No Results Found!
    </Typography>
  );
};

export default GeneralBox;

const SingleItem = ({ item, i, id, setCheckedArr, isChecked }) => {
  // const [checked, setChecked] = React.useState(isChecked);

  return (
    <Box
      display={"flex"}
      justifyContent={"space-between"}
      alignItems={"center"}
    >
      <Typography fontSize={16} display={"flex"}>
        <span
          style={{
            color: colors.gray,
            fontWeight: "bold",
            marginRight: 8,
          }}
        >
          {i + 1}{" "}
        </span>
        <Box display={{ xs: "block", md: "none" }} color={colors.gray}>
          {item?.length > 40 ? `${item?.slice(0, 40)}...` : item}
        </Box>
        <Box display={{ xs: "none", md: "block" }} color={colors.gray}>
          {item?.length > 90 ? `${item?.slice(0, 90)}...` : item}
        </Box>
      </Typography>
      <Checkbox
        size="small"
        checked={isChecked}
        onChange={() => {
          // setChecked(!checked);
          setCheckedArr(id, !isChecked);
        }}
      />
    </Box>
  );
};
