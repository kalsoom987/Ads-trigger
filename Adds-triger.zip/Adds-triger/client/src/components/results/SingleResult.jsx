import { Typography, Box } from "@mui/material";
import React from "react";

const SingleResult = () => {
  return (
    <Box>
      <Typography></Typography>
    </Box>
  );
};

export default SingleResult;
