// import { useState } from "react";
import { Box, Skeleton, Typography } from "@mui/material";
import { useResultStore } from "../../store/store";

const Nav = ({ active, setActive }) => {
  const loading = useResultStore((state) => state.loading);

  return !loading ? (
    <Box
      display={"flex"}
      flexWrap={"wrap"}
      justifyContent={"center"}
      marginX={"auto"}
      sx={{
        width: "fit-content",
        backgroundColor: "#ddd",
        paddingX: 1,
        borderRadius: 4,
      }}
    >
      <Box
        backgroundColor={active === "YouTube" ? "#fabc00" : "#4f74a8"}
        paddingX={4}
        paddingY={1}
        marginX={1}
        marginY={1}
        borderRadius={4}
        sx={{ cursor: "pointer" }}
        onClick={() => setActive("YouTube")}
      >
        <Typography color={"white"} fontWeight={"600"}>
          YouTube
        </Typography>
      </Box>
      <Box
        backgroundColor={active === "Website" ? "#fabc00" : "#4f74a8"}
        paddingX={4}
        paddingY={1}
        marginX={1}
        marginY={1}
        borderRadius={4}
        sx={{ cursor: "pointer" }}
        onClick={() => setActive("Website")}
      >
        <Typography color={"white"} fontWeight={"600"}>
          Website URL
        </Typography>
      </Box>
      <Box
        backgroundColor={active === "Keywords" ? "#fabc00" : "#4f74a8"}
        paddingX={4}
        paddingY={1}
        marginX={1}
        marginY={1}
        borderRadius={4}
        sx={{ cursor: "pointer" }}
        onClick={() => setActive("Keywords")}
      >
        <Typography color={"white"} fontWeight={"600"}>
          Keywords
        </Typography>
      </Box>
      <Box
        backgroundColor={active === "Questions" ? "#fabc00" : "#4f74a8"}
        paddingX={4}
        paddingY={1}
        marginX={1}
        marginY={1}
        borderRadius={4}
        sx={{ cursor: "pointer" }}
        onClick={() => setActive("Questions")}
      >
        <Typography color={"white"} fontWeight={"600"}>
          Questions
        </Typography>
      </Box>
    </Box>
  ) : (
    <Box display={"flex"} justifyContent={"center"}>
      <Skeleton width={600} height={100} />
    </Box>
  );
};

export default Nav;
