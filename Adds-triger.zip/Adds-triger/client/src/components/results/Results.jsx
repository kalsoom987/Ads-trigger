import { useState } from "react";
import Nav from "./Nav";
import { Box } from "@mui/material";
import "./results.css";
import Head from "./Head";
import YtBox from "./YtBox";
import GeneralBox from "./GeneralBox";
import { useResultStore } from "../../store/store";
import Search from "./Search";

const Results = () => {
  const [active, setActive] = useState("YouTube");
  const [tags, setTags] = useState([]);
  const clicked = useResultStore((state) => state.clicked);
  // getting all results arrays from store
  const googleResults = useResultStore((state) => state.googleResult);
  const keywordResults = useResultStore((state) => state.keywordResults);
  const questions = useResultStore((state) => state.questions);

  return (
    <>
      {/* Custom Search Component */}
      <Box
        width={{ xs: "95%", md: "70%", xl: "60%" }}
        marginTop={5}
        marginX={"auto"}
      >
        <Search setActive={setActive} />
      </Box>
      {clicked && (
        <Box
          width={{ xs: "95%", md: "80%", lg: "70%", xl: "65%" }}
          marginX={"auto"}
          component={"div"}
        >
          {/* Nav Buttons */}
          {/* <Nav active={active} setActive={setActive} /> */}

          {/* Head */}
          <Head tags={tags} setTags={setTags} active={active} />
          {/* Box */}
          {active === "YouTube" ? (
            <YtBox tags={tags} />
          ) : active === "Website" ? (
            <GeneralBox result={googleResults} tags={tags} active={active} />
          ) : active === "Keywords" ? (
            <GeneralBox
              result={keywordResults}
              isKeyword={true}
              tags={tags}
              active={active}
            />
          ) : active === "Questions" ? (
            <GeneralBox result={questions} tags={tags} active={active} />
          ) : null}
        </Box>
      )}
    </>
  );
};

export default Results;
