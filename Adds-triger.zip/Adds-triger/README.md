# Adds-triger
Web application to collect data to target audience for google ads  campaign.
